function splitChevrot

helpdlg('This splitting option is not yet programmed. :)',...
        'Split after Chevrot');
